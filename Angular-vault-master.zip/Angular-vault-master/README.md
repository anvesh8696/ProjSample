Angular-vault
=============
